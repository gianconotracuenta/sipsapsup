package com.example.giansaplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import java.text.DecimalFormat

class CalculatorActivity : AppCompatActivity() {

    val addition = "+"
    val subtraction = "-"
    val division = "/"
    val multiplication = "*"
    val percentage = "%"

    var currentOperation = " "
    var firstNumber: Double = Double.NaN
    var secondNumber: Double = Double.NaN

    lateinit var tvTemporaryValue: TextView
    lateinit var tvResult: TextView

    lateinit var decimalFormat: DecimalFormat


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculator)

        decimalFormat = DecimalFormat("#.##########")
        tvTemporaryValue = findViewById(R.id.tvTemporaryValue)
        tvResult = findViewById(R.id.tvResult)
    }

    fun changeOperation(b: View) {
        if (tvTemporaryValue.text.isNotEmpty() || firstNumber.toString()!= "NaN") {
            calculate()

            val boton: Button = b as Button

            if (boton.text.toString().trim() == "÷") {
                currentOperation = "/"
            } else if (boton.text.toString().trim() == "x") {
                currentOperation = "*"
            } else {
                currentOperation = boton.text.toString().trim()
            }

            tvResult.text = decimalFormat.format(firstNumber) + currentOperation
            tvTemporaryValue.text = " "
        }
    }

    fun calculate() {
        try {
            if (firstNumber.toString() != "NaN") {
                if (tvTemporaryValue.text.toString().isEmpty()) {
                    tvTemporaryValue.text = tvResult.text.toString()
                }
                secondNumber = tvTemporaryValue.text.toString().toDouble()
                tvTemporaryValue.text = ""

                when (currentOperation) {
                    "+" -> firstNumber = (firstNumber + secondNumber)
                    "-" -> firstNumber = (firstNumber - secondNumber)
                    "*" -> firstNumber = (firstNumber * secondNumber)
                    "/" -> firstNumber = (firstNumber / secondNumber)
                    "%" -> firstNumber = (firstNumber % secondNumber)
                }

            } else {
                firstNumber = tvTemporaryValue.text.toString().toDouble()
            }
        }catch (e:Exception){ }
    }

    fun selectNumber(b: View) {
        val boton: Button = b as Button
        if (tvTemporaryValue.text.toString() == "0") {
            tvTemporaryValue.text = " "
        }
        tvTemporaryValue.text = tvTemporaryValue.text.toString() + boton.text.toString()

    }

    fun equal (b:View) {
        calculate()
        tvResult.text = decimalFormat.format(firstNumber)
        firstNumber = Double.NaN
        currentOperation = ""

    }


    fun erase(b: View) {
        val boton: Button = b as Button
        if (boton.text.toString().trim() == "C") {
            if (tvTemporaryValue.text.toString().isNotEmpty()) {
                var currentData: CharSequence = tvTemporaryValue.text as CharSequence
                tvTemporaryValue.text = currentData.subSequence(0, currentData.length - 1)
            }else{
                firstNumber = Double.NaN
                secondNumber = Double.NaN
                tvTemporaryValue.text = " "
                tvResult.text = " "
            }
        } else if (boton.text.toString().trim() == "AC"){
            firstNumber = Double.NaN
            secondNumber = Double.NaN
            tvTemporaryValue.text = " "
            tvResult.text = " "
        }

    }
}
